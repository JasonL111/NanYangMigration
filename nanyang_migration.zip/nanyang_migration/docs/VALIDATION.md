# 验证报告 · 1.1.3

此版本基于 1.1.2（`9a92eb5`），修正原创港口插图在事件窗口中的横向拉伸。安装包检查 ZIP CRC 和内部、外部 SHA-256。

| 等级 | 结果 |
| --- | --- |
| A 原生文档 | 已核对 1.15.2 引擎生成日志中实际调用的 POP、State、Scope、保存变量和事件接口，以及 1.15 新 Journal/按钮类型。游戏数据、官方公告和部分参数语义仍有证据缺口，详见[兼容性调查](COMPATIBILITY_1_15.md)与[接口表](NATIVE_SCRIPT_REFERENCE.md)。 |
| B 静态 / 构建 | 执行生成、脚本结构/引用、本地化、少额探针结构、旧设计 ID 与矩阵检查。核对三个事件的纹理引用、1280×696 DXT1 DDS 的头部与画框比例。ZIP 重读全量文件，检查 CRC 与内部、外部 SHA-256。 |
| C 场景模型 | Python 3.12.14（Linux）执行 40 项 B/C 检查，全部通过，无失败或跳过。见 [实际输出](test-results.txt)。 |
| D 真实引擎 | 玩家确认 RC4 正常迁移，并报告 1.1.2 配图横向拉伸。本环境无 Victoria 3，1.1.3 的实机显示待验收。 |

## 事件图比例

1.15.1 的默认事件窗截图与源纹理配准结果为 **1120×609**，图像会铺满画框。1.15.0 的变更清单列出了 `gui/eventwindow.gui`，1.15.2 的清单未再列出。1.1.2 把原画做成 1280×960（4:3）DDS，在该画框下，横向缩放系数与纵向缩放系数的比值为 `(1120 / 1280) / (609 / 960) ≈ 1.379`。新版 DDS 为 1280×696（160:87），两个方向的缩放系数均为 0.875。画框高度可能随长文案变化，因此这组尺寸对应默认事件画框的实测例。 [1.15.1 截图测量记录](https://github.com/jakeOmega/Vic3TimelineExtended/blob/e4e9cdcc1145cc71308fada40f0f643502499720/scripts/image_pipeline/contact_sheet.py#L42-L52) · [1.15.0 变更清单](https://github.com/Victoria-3-Modding-Co-op/Modding-Digests/blob/0e94618d6a1b1599d4c78cc074282598de4d59b2/1.15.0/changes_files.md#L2892) · [1.15.2 变更清单](https://github.com/Victoria-3-Modding-Co-op/Modding-Digests/blob/0e94618d6a1b1599d4c78cc074282598de4d59b2/1.15.2/changes_files.md)

从仓库源码 PNG 等比缩放并居中裁去上下边缘。复做纹理时，从仓库根目录运行以下命令。

```sh
magick assets/nanyang_harbor.png -colorspace sRGB -resize '1280x696^' \
  -gravity center -extent 1280x696 -alpha off \
  -define dds:compression=dxt1 -define dds:mipmaps=0 \
  nanyang_migration/gfx/event_pictures/nanyang_harbor.dds
```

`tools/script_harness.py` 解释本项目的脚本子集。脚本参数只接受完整 token，作用域按测试对象建模。数值运算使用有理数与明确 floor，不模拟原生定点精度。迁移由测试用例显式注入，默认未知效果会报错。立即完成场景主动模拟合并和源对象耗尽；也覆盖延迟移动、州缓存不变、无动作、仅一端变化、部分移动、超过请求量、在国家切换后仍然锁定。时间到期和重载是模型行为，未模拟游戏存档序列化、Jomini 内存引用、异步 POP 变化或原生时间。

## 根因与执行链

RC1 的用户截图显示：832 个来源 POP，来源人口 337,827,747，各区有效实际州 5 / 32 / 3 / 13 / 7 / 12，同时本次调用与请求量为零。这把问题缩小到来源和目的地枚举之后、第一次原生移动之前。截图没有单步引擎日志，无法证明是哪个条件或绑定最先挡住请求。RC2 用原生 State/POP 枚举、生成器写出的固定调用及按存在性判断的停止标记，替换此阶段的临时列表、列表参数和布尔值比较。再检查每笔额度和来源标记，避免迭代期间状态改变造成并行抽取或重复迁移。

RC2 的后续实机截图显示 18 个格子启动、225 个目的州份为正，但配对和原生调用均为零。用户随后提供的 error.log 明确报 `has_variable trigger [This scope doesn't support variables]`，列出士兵、职员、农民和劳工等 POP，指向 `nanyang_effects.txt:403`。该位置与 RC2 中 `every_scope_pop` 的 `has_variable = nym_available` 一致。实机日志确认了这条筛选失败，不能用生成作用域表的声明覆盖。

RC4 移除了 RC3 仍残留的人口对象变量读取、写入、余额扣减和清理。迁移前核对目的州接收标记。接收过某文化的州当次不能转出该文化，避免把新到 POP 或与它合并的人口再次转移。原有人口也可能因此少迁，其他文化不受阻挡。模拟器收到任何 POP 变量操作会主动报错。同一玩家场景的模型在正式版中核验首航为 200,000 人。另验证国内同文化不重复迁移、其他文化仍可迁出、接收标记不能写入时不调用引擎，以及标记在结束时清理。

1.0.0 的上下界误用和旧模型的同类误读已经确认。1.0.1 修完上下界后，反馈仍然失败。在 1.0.2 确定能从代码确认的缺陷是“把未验证即时州差值当成失败并允许再次发起”。该路径既可能发生在请求零移动时，也可能发生在移动已执行但统计尚未更新时。反馈没有附该版本的原生日志或分阶段读数，无法确定最初停在哪一环。新版的旧日志字段不兼容是另一个可确认的问题，与 1.13.11 的原始报告分开处理。

执行链为 Journal → Button（玩家/中国资格与全局冷却/锁）→ 锁定 → Country POP 规模统计 → 每个 State Region 的实际州 → 文化×地区额度并在州间均分 → POP 内原生效果 → 通过保存的两个州重新求同文化合计 → 核对守恒且不超过请求 → 完成结算，或停止挂牌待确认。源对象被消耗后，正式脚本不读取其迁出后的大小。本国州接收标记在操作结束清除。外州接收标记在一天后到期。已有成功/冷却/历史变量保留。

最优先的待验证假设是跨国移动的参数绑定和单位、同调用链的统计/对象刷新。独立探针在一次测试周期内覆盖常数、动态值、比例、全 POP 四种请求，以及两端合计/缓存/原对象的即时与翌日读数。翌日正常人口变动可能混入结果，不能用于正式自动结账。原生操作没有已知返回值或回滚，无法确认的操作锁只随回档解除。详细原生行为尚未全部实测。

迁移开始时统计本国来源人口，地图遍历收窄为 30 个设计地理域。每个文化和目的州的有效份额以原生 Country POP 枚举筛选来源。每次实际调用另扫两州各两次，换取相互独立的核验读数。若有 P 个本国 POP、D 个目的实际州、K 次调用，由于文化数固定，配对扫描量级为 O(P·D)，核验成本取决于每笔涉及的两州 POP 数。没有轮询或无界重试。未测得实际游戏耗时。

复现：

```sh
python3 tools/build_mod.py
python3 tools/build_probe.py
python3 tools/audit_native.py --digest /path/to/Modding-Digests
python3 -m unittest discover -s tests -v
python3 tools/package_mod.py
sha256sum -c nanyang_migration.zip.sha256 nanyang_native_probe.zip.sha256
```
